<?php

require "bd.php";

if (isset($_GET['id'])) {
    $id_prod = $_GET['id'];

    if (mostrarProductoById($id_prod)) {
        $producto = mostrarProductoById($id_prod);
    } else {
        $mensaje = "Error: No se pudo mostrar el detalle del producto. Verifica si existe o intenta nuevamente.";
    }
} else {
    header('Location:listado.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body style="width: 70%; margin: auto; background-color: rgb(140, 202, 226);">
<br><br>
    <h2 class="text-center">DETALLE DE PRODUCTO</h2><br><br>
    <table class="table table-dark table-striped" style="align-content: center; text-align: center; ">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Nombre corto</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Familia</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php
                    echo "<td>$producto[id]</td>";
                    echo "<td>$producto[nombre]</td>";
                    echo "<td>$producto[nombre_corto]</td>";
                    echo "<td>$producto[descripcion]</td>";
                    echo "<td>$producto[pvp]</td>";
                    
                    $nombre_familia = mostrarNombreFamiliaByCod($producto["familia"]);
                    
                    echo "<td>$nombre_familia[0]</td>";    
                ?>
            </tr>
        </tbody>
    </table>

    <a href="listado.php" class="btn btn-primary"> Volver </a>
</body>
</html>