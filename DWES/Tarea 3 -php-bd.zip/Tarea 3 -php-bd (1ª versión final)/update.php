<?php
require "bd.php";
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $producto = mostrarProductoById($id);
    if (!$producto) {
        echo "<p>Error: No se encontró el producto.</p>";
    }
} else {
    header('Location:listado.php');
}

$familias = mostrarFamilias();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body style="width: 70%; margin: auto; background-color: rgb(140, 202, 226);">
    <br><br>
    <h2 class="text-center">ACTUALIZAR PRODUCTO</h2><br><br>

    <form action="procesar_actualizacion.php" method="POST">
        <div class="row mb-3">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="col-md-6">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" name="nombre" class="form-control" value="<?php echo $producto['nombre']; ?>" required>
            </div>
            <div class="col-md-6">
                <label for="nombre_corto" class="form-label">Nombre Corto</label>
                <input type="text" name="nombre_corto" class="form-control" value="<?php echo $producto['nombre_corto']; ?>" required>

            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="pvp" class="form-label">Precio (€)</label>
                <input type="number" step="0.01" name="pvp" class="form-control" value="<?php echo $producto['pvp']; ?>" required>
            </div>
            <div class="col-md-6">
                <label for="familia" class="form-label">Familia</label>
                <select name="familia" class="form-control" required>
                    <?php
                    if ($familias) {
                        foreach ($familias as $familia) {
                            $selected = ($producto['familia'] == $familia['cod']) ? 'selected' : '';
                            echo "<option value='{$familia['cod']}' $selected>{$familia['nombre']}</option>";
                        }
                    } else {
                        echo "<option value=''>No hay familias disponibles</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="col-md-10">
            <label for="descripcion" class="form-label">Descripción</label><br>
            <textarea name="descripcion" rows="5" cols="50" class="form-control" required><?php echo $producto['descripcion']; ?></textarea><br><br>
        </div>
        <button type="submit" class="btn btn-success">Actualizar</button>
        <button type="reset" class="btn btn-warning">Limpiar</button>
        <a href="listado.php" class="btn btn-primary">Volver</a>
    </form>
</body>

</html>