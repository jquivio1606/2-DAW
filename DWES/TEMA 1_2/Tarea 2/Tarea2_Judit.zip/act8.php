<?php
/*  JUDIT QUIROS VIOLERO  */

function manejadorErrores($errno, $str){
    echo "Ocurrió el error: $errno. $str";
}

set_error_handler("manejadorErrores");
$a= $b

?>