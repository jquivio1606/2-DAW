<?php
/*  JUDIT QUIROS VIOLERO  */
$cadena= "H-o-l-a";

$array = explode("-",$cadena);

foreach($array as $valor){
    echo $valor;
}
