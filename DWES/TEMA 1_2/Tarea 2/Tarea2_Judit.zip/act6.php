<?php
/*  JUDIT QUIROS VIOLERO  */

/* Abro el fichero  php.ini  busco donde pone: 
        error_reporting=E_ALL & ~E_DEPRECATED & ~E_STRICT
        
    En esa linea le añado al final & ~E_NOTICE , y lo guardo.
    Como esta puesto en php.ini display_errors en on, si en el codigo 
    hubiera algún error lo mostraria en el navegador. Todos menos el E_NOTICE
*/

?>