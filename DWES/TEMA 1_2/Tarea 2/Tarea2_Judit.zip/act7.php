<?php
/*  JUDIT QUIROS VIOLERO  */

// Poniendo error_reporting(E_ALL) se deben mostrar todos los errores.
error_reporting(E_ALL);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

?>