<?php
/*  JUDIT QUIROS VIOLERO  */

function suma ($a, $b){
    return $a+$b;
}

function resta ($a, $b){
    return $a-$b;
}

function multiplicacion ($a, $b){
    return $a*$b;
}

echo "\nEl resultado de la suma es: ".suma(2,4);
echo "\nEl resultado de la resta es: ".resta (5,2);
echo "\nEl resultado de la multiplicacion es: ".multiplicacion(4,2);

?>