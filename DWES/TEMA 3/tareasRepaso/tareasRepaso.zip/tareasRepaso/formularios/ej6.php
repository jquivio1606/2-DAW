<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_FILES["archivo"])){
            echo "Nombre del fichero: ".$_FILES["archivo"]["name"]."<br>";
            echo "Nombre temporal del fichero: ".$_FILES["archivo"]["tmp_name"]."<br>";
        } else {
            echo "No se ha subido ningún fichero";
        }
    }
?>